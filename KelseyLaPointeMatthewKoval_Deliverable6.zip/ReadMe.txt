@Author Kelsey Lapointe
@Author Matthew Koval

Instructions
------------
The GUI will launch and handle the user login, but will not play the game since the buttons aren't handled properly. 
But, the game can still be played through the server and 2 console's(Putty windows to represent the client).

Using the PDF
-------------
There is a link on the title page of the .pdf that when clicked lets you open up a google docs version of the
PDF that allows you to use the bookmarks if they do not work in the table of contents.